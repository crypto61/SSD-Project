# Django Shell
```
python3 -m django shell

```
