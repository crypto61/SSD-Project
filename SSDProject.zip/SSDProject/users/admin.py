from django.contrib import admin
from .models import Ticket

# Register your models hereo.

admin.site.register(Ticket)
